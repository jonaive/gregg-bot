# Greg Bot
[![CI](https://github.com/orgbookclub/greg-bot/actions/workflows/main.yml/badge.svg)](https://github.com/orgbookclub/greg-bot/actions/workflows/main.yml) 
[![Deployed](https://github.com/orgbookclub/greg-bot/actions/workflows/deploy-azure.yml/badge.svg)](https://github.com/orgbookclub/greg-bot/actions/workflows/deploy-azure.yml)
[![Discord](https://img.shields.io/discord/811077227449286667.svg?label=&logo=discord&logoColor=ffffff&color=7389D8&labelColor=6A7EC2)](https://discord.gg/BookClubs)

